from .allrecipes import AllRecipes
from .chefkoch import Chefkoch
from .fooby import Fooby
from .local_file_parser import ParseString
